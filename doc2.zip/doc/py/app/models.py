from .database import Base
from sqlalchemy import Column, String, Boolean, Integer


class DeviceInfo(Base):
    __tablename__ = 'DeviceInfo'
    token = Column(String(100), primary_key = True)
    username = Column(String(100), default = 'user')


class Configuration(Base):
    __tablename__ = 'Configuration'
    id = Column(Integer, primary_key = True, autoincrement = True)
    modelUrl = Column(String(100))
    frequency = Column(Integer)
    federated = Column(Boolean)
