#%%
import sys

#https://stackoverflow.com/questions/4675728/redirect-stdout-to-a-file-in-python
#https://stackoverflow.com/questions/20525587/python-logging-in-multiprocessing-attributeerror-logger-object-has-no-attrib
class Logger(object):
    def __init__(self, filename="/home/user/proj/log/Default.log"):
        self.terminal = sys.stdout
        self.log = open(filename, "a")

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)
        self.log.flush()

    def flush(self):
        pass
#%%

sys.stdout = Logger()

#%%
print ("ok") # this is should be saved in yourlogfilename.txt

#%%
print ("ok2") # this is should be saved in yourlogfilename.txt



#%%
class Program:
    language = 'Python'
    version = '3.6'

#%%
#  alex
from sqlalchemy import create_engine
# engine = create_engine("sqlite+pysqlite:///:memory:", echo=True)

# https://stackoverflow.com/questions/8348506/grant-remote-access-of-mysql-database-from-any-ip-address
# https://stackoverflow.com/questions/29355674/how-to-connect-mysql-database-using-pythonsqlalchemy-remotely
engine = create_engine(
    "mysql+mysqldb://user:pass@doc_db_1:3306/test",
)
 
#%%
from sqlalchemy import text

with engine.connect() as conn:
    result = conn.execute(text("select 'hello world'"))
    print(result.all())

#%%
with engine.connect() as conn:
    conn.execute(text("CREATE TABLE some_table (x int, y int)"))
    conn.execute(
        text("INSERT INTO some_table (x, y) VALUES (:x, :y)"),
        [{"x": 1, "y": 1}, {"x": 2, "y": 4}],
    )
    conn.commit()
#%%
with engine.begin() as conn:
    conn.execute(
        text("INSERT INTO some_table (x, y) VALUES (:x, :y)"),
        [{"x": 6, "y": 8}, {"x": 9, "y": 10}],
    )


